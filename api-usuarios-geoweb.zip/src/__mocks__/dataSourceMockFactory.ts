import { DataSource } from "typeorm"

export const dataSourceMockFactory = () => {
    
}